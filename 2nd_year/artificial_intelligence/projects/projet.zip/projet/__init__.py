"""
package projet

Rassemble les modules et classes pour la réalisation du TP IA des SRI2A
"""
