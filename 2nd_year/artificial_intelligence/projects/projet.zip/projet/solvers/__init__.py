"""
package solvers

Rassemble les modules et classes pour les solvers a utiliser lors du TP IA des SRI2A
"""
