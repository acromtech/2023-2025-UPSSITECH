"""
package etape1

Rassemble les modules et classes pour la réalisation de l'etape 1 du TP IA des SRI2A
"""
