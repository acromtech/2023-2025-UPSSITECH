# -*- coding: utf-8 -*-
"""
tp 4
"""

from random import random, randint
from math import exp
import matplotlib.pyplot as plt
import numpy as np

def blob(x,y,n,scale=1.):
    """
    nuage de points autour de (x,y)
    """     
    res = []
    for i in range(n):
        res.append((x+scale*(1.-2*random()),y+scale*(1.-2*random())))
    return res
    
def centre(pts):
    x,y = zip(*pts)
    n = len(pts)
    return sum(x)/n,sum(y)/n

def separateur(g1,g2):
    c1 = centre(g1)
    c2 = centre(g2)
    m = centre([c1,c2])
    c1x, c1y = c1
    c2x, c2y = c2
    return (m,(c1x-c2x,c1y-c2y))

def plot_group(g,style="bo"):
    coords = zip(*g)
    plt.plot(coords[0],coords[1],style)
    
def plot_separateur(p,scale=3):
    m,w = p 
    tw = (-w[1],w[0])
    plt.plot([m[0]+scale*tw[0],m[0]-scale*tw[0]],[m[1]+scale*tw[1],m[1]-scale*tw[1]],"y-")

    
def classify(pt,separateur):
    m,w = separateur
    prod = 0
    for (xi,mi,wi) in zip(pt,m,w):
        prod += (xi-mi)*wi
    if prod>0:
        return 1
    elif prod<0:
        return -1
    else:
        return 0
    
g1 = blob(0.3,0.6,20,scale=0.1)
g2 = blob(0.6,0.4,15,scale=0.15)


plt.xlim(0,1)
plt.ylim(0,1)
plt.axes().set_aspect('equal')
plt.xscale("linear")
plt.yscale("linear")


classes = {1:"b",-1:"r"}

plot_group(g1,"bo")
plot_group(g2,"ro")
plot_group([centre(g1),centre(g2)],"yo")
s = separateur(g1,g2)
plot_separateur(s)

for i in range(10):
    test = random(),random()
    plt.plot(test[0],test[1],classes[classify(test,s)]+"x")
    
#    
data = np.genfromtxt('iris.txt', dtype=None,delimiter=',',names=True)
plt.cla()
#
f1,f2 = "petal_l","petal_w"
#
plot_group(zip(data[f1][data["classe"]=="Iris-virginica"],data[f2][data["classe"]=="Iris-virginica"]),"go")
plot_group(zip(data[f1][data["classe"]=="Iris-setosa"],data[f2][data["classe"]=="Iris-virginica"]),"yo")
plot_group(zip(data[f1][data["classe"]=="Iris-versicolor"],data[f2][data["classe"]=="Iris-virginica"]),"ro")
#
#  
#  
    
