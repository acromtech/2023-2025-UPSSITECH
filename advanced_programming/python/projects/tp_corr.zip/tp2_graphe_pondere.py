# -*- coding: utf-8 -*-


from tp2_pile import Stack
import heapq
from operator import itemgetter
from math import log

def argmin(l,f,filter=False):
    """find index of first min (wrt f) in a list"""
    idxmin = -1 
    valmin = float("inf")
    for (i,x) in enumerate(l):        
        if f(x)<valmin and not(filter(x)):
            idxmin = i
            valmin = f(x)
    return idxmin

# version 1: adjacency list / avec poids
class Graph: 

    def __init__(self,directed=True,weighted=False):
        self._nodes = {}
        self._directed = directed
        self._weighted = weighted
        self._cache = None

    def add_node(self,noeud,links=[]):
        """liens = liste de noeuds relies, éventuellement avec un poids
        """
        if links == []:
            self._nodes[noeud] = {}
        for n in links: 
            if self._weighted:
                x,w = n
            else:
                x,w = (n,1)
            if x not in self:
                    self._nodes[x] = {}
            self.add_edge(noeud,x,weight=w)
            

    def add_edge(self,n1,n2,weight=1):
        if n1 in self:
            self._nodes[n1][n2]=weight
        else: 
            self._nodes[n1] = {n2:weight}
        if not(self._directed):
            if n2 in self:
                self._nodes[n2][n1]=weight
            else: 
                self._nodes[n2] = {n1:weight}

    def from_file(self,filename):
        """ init from edge list with weight = closeness
        transformed to distance by 1/(1+x)
        """
        all = open(filename).readlines()[1:]
        all = [x.strip().split(",") for x in all]
        for (s,o,w) in all:
            self.add_edge(s,o,weight=1/(1+float(w)))
        
            
    def __contains__(self,noeud):
        return noeud in self._nodes

    def origin(self,noeud):
        return self._nodes.get(noeud,{})

    def weight(self,source,target):
        return self.origin(source).get(target,float("inf"))    

    def degree(self,node):
        return len(self[node])
    
    def __getitem__(self,x):
        return self.origin(x)

    def to(self,noeud):
        return [x for x in self._nodes if noeud in self._nodes[x]]
        
    def __repr__(self):
        res= []
        for n in self._nodes: 
            one = "%s: %s"%(n,"\t".join(["%s --(%s)--> %s"%(n,self._nodes[n][x],x) for x in self._nodes[n]]))
            res.append(one)
        return "\n".join(res)
            
    def __len__(self):
        return len(self._nodes)

    def depth_first(self,start=None):
        if start is None:
            start = list(self._nodes.keys())[0]
        stack = Stack()
        stack.push(start)
        res = []
        seen = set()
        while not(stack.empty()): 
            one = stack.pop()
            if one not in seen: 
                res.append(one)
                seen.add(one)
                [stack.push(x) for x in self.origin(one)]
        return res


    def comp_con(self):
        nodes = set(self._nodes.keys())
        done = set()
        todo = nodes - done
        comps = []
        while todo != set():
            start = todo.pop()
            comp = set(self.depth_first(start))
            done |= comp
            todo -= comp
            comps.append(comp)
        return comps
            


    def __iter__(self):
        """only works if the graph is strongly connected"""

        start = list(self._nodes.keys())[0]
        stack = Stack()
        stack.push(start)
        res = []
        seen = set()
        while not(stack.empty()): 
            one = stack.pop()
            if one not in seen: 
                res.append(one)
                seen.add(one)
                yield one
                [stack.push(x) for x in self.origin(one)]


    def dijkstra(self,start):
        """disjkstra implementation with a heap
        avoid resorting everytime something is updated , at the cost of heap insertion
        
        returns table of shortest distance + shortest paths as node pairs
        """
        table = {start:0}
        paths = {start:None}
        n = len(self)
        cpt = 1
        queue = []
        heapq.heappush(queue,(0,start))
        while cpt<=n and queue!=[]:
            cpt = cpt + 1
            #print queue
            val, current = heapq.heappop(queue)
            for y in self.origin(current):
                new_path = val + self.origin(current)[y]
                if table.get(y,float("inf"))>new_path:
                    table[y] = new_path
                    paths[y] = current
                    heapq.heappush(queue,(table[y],y))
        return table,paths

    def dijkstra_naif(self,start):
            """naive impl. with min search everytime
            """
            table = {start:0}
            paths = {start:None}
            n = len(self.depth_first(start))
            done = set()
            cpt = 1
            while cpt <= n:
                cpt = cpt + 1
                all = list(table.items())
                current, val   = all[argmin(all,lambda a_b: a_b[1],filter=lambda x : x[0] in done)]
                #print "table = ", all
                #print "current, val = ", current, val
                done.add(current)
                #print done
                for y in self.origin(current):
                    new_path = val  + self.origin(current)[y]
                    if table.get(y,float("inf"))>new_path:
                        table[y] = new_path
                        paths[y] = current
            return table,paths

    def dijkstra_naif2(self,start):
            """naive impl. with min search everytime
            """
            table = {start:0}
            paths = {start:None}
            n = len(self.depth_first(start))
            done = set()
            cpt = 1
            while cpt <= n:
                cpt = cpt + 1
                all = list((x,y) for (x,y) in list(table.items()) if x not in done)
                all.sort(key=itemgetter(1))
                current , val = all[0]
                #print "table = ", all
                #print "current, val = ", current, val
                done.add(current)
                #print done
                for y in self.origin(current):
                    new_path = val + self.origin(current)[y]
                    if table.get(y,float("inf"))>new_path:
                        table[y] = new_path
                        paths[y] = current
            return table,paths

    def shortest(self,from_node,to_node):
        if self._cache is None:
            self.all_shortest(self,from_node)
        return self._cache[0][to_node]

    def all_shortest(self,start):
        """diskjsta"""
        self._cache = self.dijkstra(start)
        return self._cache

    def max_degree(self):
        return max([(self.degree(n),n) for n in self._nodes])
            

    
### test


g = Graph(weighted=True)
g.add_node(1,[(2,1),(3,2),(4,8)])
g.add_node(2,[(5,2),(6,2)])
g.add_node(4,[(7,3)])
g.add_node(5,[])
g.add_node(3,[(6,1),(4,1.5),(8,2)])
g.add_node(4,[(6,2),(3,2),(8,3)])
g.add_node(9,[(10,1)])



if __name__=="__main__":
    print("graphe pondéré, exemple:")
    print(g)

    print("weight (1,4)=", g.weight(1,4))
    print("weight (1,5)=", g.weight(1,5))
    print("parcours profondeur:")
    print(g.depth_first(1))
    print("composantes connexes:")
    print(g.comp_con())
    print("test disjkstra, avec distance depuis départ + arêtes choisies")
    print("disjkstra version 1:")
    print(g.dijkstra(1))
    print("disjsktra version 2:")
    print(g.dijkstra_naif(1))

    print("estimation du temps de calcul sur 1000 itérations de chaque:")
    from time import time
    t0 = time()
    for i in range(1000):
        g.dijkstra(1)
    t1 = time()
    for i in range(1000):
        g.dijkstra_naif(1)
    t2 = time()

    print("version 1:", t1 - t0)
    print("version 2:", t2 - t1)
    print("="*50)
    print("exemple Game of Thrones")
    got = Graph(weighted=True,directed=False)
    got.from_file("stormofswords.csv")
    print("Tyrion:", got["Tyrion"], got.degree("Tyrion"))
    print("Sansa:",got["Sansa"])
    
    print("degre max",  got.max_degree())
    print("="*50)
    print("composantes connexes")
    all = got.comp_con()
    print(len(all))
    for x in all:
        print(x)
    print("="*50)
    all_scores = []
    for one in got.depth_first("Tyrion"):
        table, paths = got.all_shortest(one)
        all_scores.append((sum(table.values())/len(table),one))
    all_scores.sort()
    print("top 10 près = persos centraux \n", all_scores[:10])
    print("top 10 loin = persos periphériques \n", all_scores[-10:])
    got.all_shortest("Tyrion")
    print("Tyrion->Stannis", got.shortest("Tyrion","Stannis"))

# bonus : surcharger 
# + fusion graphes 
# - suppression arcs
# * intersection
# ?
