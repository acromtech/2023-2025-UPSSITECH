# -*- coding: utf-8 -*-
"""
tp 4: clustering
   kmeans
   application -> iris
"""

from random import random, randint, sample
from math import exp
import matplotlib.pyplot as plt
import numpy as np

def blob(x0,y0,n,scale=1.):
    """
    nuage de points autour de (x,y)
    """   
    return np.random.uniform(low=np.array((x0,y0))-scale,high=np.array((x0,y0))+scale,size=(n,2))

    
# vu en cours
def centre(pts):
    x,y = pts[:,0].mean(), pts[:,1].mean()
    return np.array([x,y])

# non vu en cours
def centre(pts):
    return pts.mean(axis=0)


# todo: un seul vecteur dès le début
def generate_centers(pts,n_clusters=2):
    xmin, ymin = pts.min(axis=0)
    xmax, ymax = pts.max(axis=0)
    centers_x = np.random.uniform(low=xmin,high=xmax,size=n_clusters).reshape(n_clusters,1)
    centers_y = np.random.uniform(low=ymin,high=ymax,size=n_clusters).reshape(n_clusters,1)
    centers = np.concatenate((centers_x,centers_y),axis=1)
    return centers



def distance_to_centers(centers,pts):
    # (a) distance tous les points <-> tous les centres
    distances = []
    for cx,cy in centers:
        distances.append((cx-pts[:,0])**2+(cy-pts[:,1])**2)
    return np.array(distances)

# 2e version complètement vectorisé avec l'astuce 
def cross_dist(x,y):
    """
    utilise le fait que  (x-y)^2 = x^2 + y^2 - 2*(xy)
    aussi en matriciel
    """
    dists = -2 * np.dot(x, y.T) + np.sum(y**2,    axis=1) + np.sum(x**2, axis=1)[:, np.newaxis]
    return np.sqrt(dists)

# todo: centres = vecteurs aussi
def kmeans(pts,n_clusters=2):
    centers = generate_centers(pts,n_clusters=n_clusters)
    nb_iter = 0 
    convergence = False
    while not(convergence): 
        # (1) associe points -> center le plus proche / 2 versions
        #m = distance_to_centers(centers,pts)
        m = cross_dist(centers,pts)
        # m  size = (n_clusters x nb of instances)
        pts_labels = np.argmin(m,axis=0)
        
        # (2) calcul des nvx centres
        new_centers = []
        for k in range(n_clusters):
            new_group = pts[pts_labels==k]
            if len(new_group) == 0: 
                new_centers.append(centers[k])
            else:
                new_centers.append(centre(new_group))
        plt_clstng(pts,pts_labels,centers)
        new_centers = np.array(new_centers)
        diff = np.linalg.norm((new_centers-centers))
        centers = new_centers
        #plt_clstng(pts,pts_labels,centers)
        plt.show()
        nb_iter = nb_iter + 1
        if diff< 1E-10: 
            convergence = True
            print("convergence in %s iterations"%nb_iter)

    return centers, pts_labels

##################
# partie k-medoids
##################
def swap_pts(pts,medoids_idx,j,c,ck):
    swap_c, swap_j = (j,c)
    #pts[swap_c,:], pts[swap_j,:] = pts[swap_j,:], pts[swap_c,:].copy() 
    medoids_idx[ck] = j
    return swap_c, swap_j


def k_medoids(pts,n_clusters=3,precomputed=None):
    # my python/numpy version of Partitioning Around Medoids algorithm
    
    # init to random medoids
    medoids_idx = np.random.choice(pts.shape[0], n_clusters, replace=False)
    # assign pts to closest medoids; m = (n_clusters x nb of instances)
    #m = distance_to_centers(pts[medoids_idx],pts)
    m = cross_dist(pts[medoids_idx],pts)
    pts_labels = np.argmin(m,axis=0)
    # compute cost of partition = sum of distance of pts to their medoids
    # (magic of advanced indexing)
    cost = m[pts_labels,np.arange(m.shape[1])].sum()
    convergence = False
    it  = 0 
    max_it = 10
    print("start cost",cost)
    print("initial medoids",medoids_idx)
    print(pts[medoids_idx])
    while not(convergence):
        current_cost = cost
        print("current best",current_cost)
        # k is cluster number, cid is center id in point matrix
        for k, cid in enumerate(medoids_idx):
            for j in range(pts.shape[0]):
                if j not in medoids_idx:
                    #print("swap:",cid,j) 
                    # swap j and c in medoids and pts matrix
                    swap_c, swap_j = swap_pts(pts,medoids_idx,j,cid,k)
                    # recompute cost
                    m = distance_to_centers(pts[medoids_idx],pts)
                    pts_labels = np.argmin(m,axis=0)
                    new_cost = m[pts_labels,np.arange(m.shape[1])].sum()
                    #print("cost",new_cost)
                    if new_cost>cost:
                        j,cid = swap_pts(pts,medoids_idx,swap_c,swap_j,k)
                        #print("unswap")
                    else:
                        cost = new_cost
                        print("new medoids",medoids_idx)
                        print("cost=",cost)
        print("end iteration",it)
        it = it + 1
        if  it>=max_it :# cost cant increase but safer wrt rounding
            convergence = True
        plt_clstng(pts, pts_labels,pts[medoids_idx])
    return pts[medoids_idx], pts, pts_labels



######### Visualization ########
_colors = "brygo"



def plot_group(g,style="bo"):
    plt.plot(g[:,0],g[:,1],style)
    

def plt_clstng(pts,labels,centers):
    for k in range(len(centers)):
        group = pts[labels==k]
        plot_group(group,_colors[k]+".")
        plt.plot(centers[k][0],centers[k][1],_colors[k]+"X",markersize=15,alpha=0.5)
    plt.show()


########## main     
import sys

if len(sys.argv)==2:
    nbclusters = int(sys.argv[1])
else:
    nbclusters = 3

g1 = blob(0.14,0.6,40,scale=0.1)
g2 = blob(0.6,0.4,30,scale=0.15)
g3 = blob(0.2,0.2,50,scale=0.1)
lg = [g1,g2,g3]

all = np.concatenate(lg,axis=0)

centers, pts_labels = kmeans(all,n_clusters=nbclusters)

plt.xlim(0,1)
plt.ylim(0,1)
plt.axes().set_aspect('equal')
plt.xscale("linear")
plt.yscale("linear")


#plot_group(all)
#plt.show()
# test medoids
#centers, all, pts_labels = k_medoids(all,n_clusters=3)
#print(centers)
#plt_clstng(all,pts_labels,centers)
