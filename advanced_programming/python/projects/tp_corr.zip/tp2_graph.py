# -*- coding: utf-8 -*-


from tp2_pile import Stack
import heapq
from operator import itemgetter

def argmin(l,f,filter=False):
    """find index of first min (wrt f) in a list"""
    idxmin = -1 
    valmin = float("inf")
    for (i,x) in enumerate(l):        
        if f(x)<valmin and not(list(filter(x))):
            idxmin = i
            valmin = f(x)
    return idxmin

# version 1: adjacency list / sans poids 
class Graph: 

    def __init__(self,directed=True):
        self._nodes = {}
        self._directed = directed
        self._cache = None

    def add_node(self,noeud,links=[]):
        """liens = liste de noeuds relies
        """
        if links == []:
            self._nodes[noeud] = set([])
        for x in links: 
            if x not in self:
                self._nodes[x] = set([])
            self.add_edge(noeud,x)
            

    def add_edge(self,n1,n2):
        if n1 in self:
            self._nodes[n1].add(n2)
        else: 
            self._nodes[n1] = set([n2])
        if not(self._directed):
            self.add_edge(n2,n1)

    def __contains__(self,noeud):
        return noeud in self._nodes

    def origin(self,noeud):
        return self._nodes.get(noeud,set([]))

    def __getitem__(self,x):
        return self.origin(x)

    def to(self,noeud):
        return [x for x in self._nodes if noeud in self._nodes[x]]
        
    def __repr__(self):
        res= []
        for n in self._nodes: 
            one = "%s: %s"%(n,"\t".join(["%s -> %s"%(n,x) for x in self._nodes[n]]))
            res.append(one)
        return "\n".join(res)
            
    def __len__(self):
        return len(self._nodes)

    def depth_first(self,start=None):
        if start is None:
            start = list(self._nodes.keys())[0]
        stack = Stack()
        stack.push(start)
        res = []
        seen = set()
        while not(stack.empty()): 
            one = stack.pop()
            if one not in seen: 
                res.append(one)
                seen.add(one)
                [stack.push(x) for x in self.origin(one)]
        return res

    def __iter__(self):
        """only works if the graph is strongly connected"""

        start = list(self._nodes.keys())[0]
        stack = Stack()
        stack.push(start)
        res = []
        seen = set()
        while not(stack.empty()): 
            one = stack.pop()
            if one not in seen: 
                res.append(one)
                seen.add(one)
                yield one
                [stack.push(x) for x in self.origin(one)]


    def dijkstra(self,start):
        """disjkstra implementation with a heap
        avoid resorting everytime something is updated , at the cost of heap insertion
        
        returns table of shortest distance + shortest paths as node pairs
        """
        table = {start:0}
        paths = {start:None}
        n = len(self)
        cpt = 1
        queue = []
        heapq.heappush(queue,(0,start))
        while cpt<=n:
            cpt = cpt + 1
            val, current = heapq.heappop(queue)
            for y in self.origin(current):
                new_path = val + 1
                if table.get(y,float("inf"))>new_path:
                    table[y] = new_path
                    paths[y] = current
                    heapq.heappush(queue,(table[y],y))
        return table,paths

    def dijkstra_naif(self,start):
            """naive impl. with min search everytime
            """
            table = {start:0}
            paths = {start:None}
            n = len(self)
            done = set()
            cpt = 1
            while cpt <= n:
                cpt = cpt + 1
                all = list(table.items())
                current, val   = all[argmin(all,lambda a_b: a_b[1],filter=lambda x : x[0] in done)]
                #print "table = ", all
                #print "current, val = ", current, val
                done.add(current)
                #print done
                for y in self.origin(current):
                    new_path = val + 1
                    if table.get(y,float("inf"))>new_path:
                        table[y] = new_path
                        paths[y] = current
            return table,paths

    def dijkstra_naif2(self,start):
            """naive impl. with min search everytime
            """
            table = {start:0}
            paths = {start:None}
            n = len(self)
            done = set()
            cpt = 1
            while cpt <= n:
                cpt = cpt + 1
                all = list((x,y) for (x,y) in list(table.items()) if x not in done)
                all.sort(key=itemgetter(1))
                current , val = all[0]
                #print "table = ", all
                #print "current, val = ", current, val
                done.add(current)
                #print done
                for y in self.origin(current):
                    new_path = val + 1
                    if table.get(y,float("inf"))>new_path:
                        table[y] = new_path
                        paths[y] = current
            return table,paths


    def shortest(self,from_node,to_node):
        if self._cache is None:
            self.all_shortest(self,from_node)
        return self._cache[0][to_node]

    def all_shortest(self,start):
        """diskjsta"""
        self._cache = self.dijkstra(start)
        return self._cache
        
### test
test="""g = Graph()
g.add_node(1,[2,3,4])
g.add_node(2,[5,6])
g.add_node(4,[7])
g.add_node(5,[8])
"""

g = Graph()
g.add_node(1,[2,3,4])
g.add_node(2,[5,6])
g.add_node(4,[7])
g.add_node(5,[])
g.add_node(3,[6,4,8])
g.add_node(4,[6,3,8])

if __name__=="__main__":
    print("graph exemple:")
    print(g)
    print("parcours profondeur:")
    print(g.depth_first(1))
    print("disjkstra version 1:")
    print(g.dijkstra(1))
    print("disjsktra version 2:")
    print(g.dijkstra_naif2(1))

    print("estimation du temps de calcul sur 1000 itérations de chaque:")
    from time import time
    t0 = time()
    for i in range(1000):
        g.dijkstra(1)
    t1 = time()
    for i in range(1000):
        g.dijkstra_naif2(1)
    t2 = time()

    print("version 1:", t1 - t0)
    print("version 2:", t2 - t1)
    print(g.all_shortest(1))
