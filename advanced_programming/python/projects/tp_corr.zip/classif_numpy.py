# -*- coding: utf-8 -*-
"""
tp 4
"""

from random import random, randint
from math import exp
import matplotlib.pyplot as plt
import numpy as np

def blob(x0,y0,n,scale=1.):
    """
    nuage de points autour de (x,y)
    """   
    x = np.random.uniform(low=x0-scale,high=x0+scale,size=n)
    y = np.random.uniform(low=y0-scale,high=y0+scale,size=n)
    return np.array([x,y])
    
    
def centre(pts):
    return np.array([pts[0].mean(),pts[1].mean()])


def separateur(g1,g2):
    c1 = centre(g1)
    c2 = centre(g2)
    m = 0.5*(c1+c2)
    c1x, c1y = c1
    c2x, c2y = c2
    return (m,(c1x-c2x,c1y-c2y))

def plot_group(g,style="bo"):
    plt.plot(g[0,:],g[1,:],style)
    
def plot_separateur((m,w),scale=3):
    tw = (-w[1],w[0])
    plt.plot([m[0]+scale*tw[0],m[0]-scale*tw[0]],[m[1]+scale*tw[1],m[1]-scale*tw[1]],"y-")

    
def classify(pt,separateur):
    m,w = separateur
    prod = (pt-m).dot(w)
    if prod>0:
        return 1
    elif prod<0:
        return -1
    else:
        return 0
    
g1 = blob(0.3,0.6,20,scale=0.1)
g2 = blob(0.6,0.4,15,scale=0.15)


plt.xlim(0,1)
plt.ylim(0,1)
plt.axes().set_aspect('equal')
plt.xscale("linear")
plt.yscale("linear")


classes = {1:"b",-1:"r",0:"g"}

plot_group(g1,"bo")
plot_group(g2,"ro")
plt.plot(centre(g1)[0],centre(g1)[1],"yo")
plt.plot(centre(g2)[0],centre(g2)[1],"yo")
s = separateur(g1,g2)
plot_separateur(s)

# peut etre numpy-isé aussi
for i in range(10):
    test = random(),random()
    plt.plot(test[0],test[1],classes[classify(test,s)]+"x")
    
#    
data = np.genfromtxt('iris.txt', dtype=None,delimiter=',',names=True)
#plt.cla()
#
f1,f2 = "petal_l","petal_w"
#
#plot_group(zip(data[f1][data["classe"]=="Iris-virginica"],data[f2][data["classe"]=="Iris-virginica"]),"go")
#plot_group(zip(data[f1][data["classe"]=="Iris-setosa"],data[f2][data["classe"]=="Iris-virginica"]),"yo")
#plot_group(zip(data[f1][data["classe"]=="Iris-versicolor"],data[f2][data["classe"]=="Iris-virginica"]),"ro")
#
#  
#  
    