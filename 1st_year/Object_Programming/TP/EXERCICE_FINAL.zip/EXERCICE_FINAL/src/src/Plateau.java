package src;

public class Plateau extends Jeu {
	public Plateau(int taille) {
		
	}
	public void affichage();
	public String toString();
	public int getTaille();
	public CasePlateau getCasePlateau(int nl,int nc);
}
