package src;

public enum Action {
	DEPLACEMENT,
	TIR,
	PECHE
}
