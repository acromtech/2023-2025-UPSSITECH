package src;

public class Jeu {
	//Attributes
	private boolean fini;
	
	//Constructor
	public void Jeu(int taille) {
		
	}
	
	//Methods
	public void jouer() {
		
	}
	private void finDePartie(int numJ) {
		
	}
	private void majJeuAvCommande(Commande cmd) {
		
	}
	private void majJeuCasTir(Commande cmd) {
		
	}
	private void majJeuCasPeche(Commande cmd) {
		
	}
	private boolean majListeNavire(Navire n) {
		
	}
	private void majJeuCasDeplacement(Commande cmd) {
		
	}
	public void choixJoueurs() {
		
	}
	public String toString() {
		
	}
	public void attributionNavire() {
		
	}
	public void positionnementNavire() {
		
	}
	public void main(String [] args) {
		
	}
	
	
}
