package src;

public abstract interface JHumain extends Joueur {
	public void interrogationParClavier() {
		
	}
}
