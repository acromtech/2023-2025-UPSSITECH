package src;

public abstract class NavireProfondeur extends Navire {
	public NavireProfondeur(int rang,TypeNav t,int numEq) {
		super(rang,t,numEq);
	}
}