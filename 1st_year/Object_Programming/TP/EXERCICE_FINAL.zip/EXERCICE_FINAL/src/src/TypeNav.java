package src;

public enum TypeNav {
	CHALUTIER,
	DESTROYER,
	SOUSMARIN
}
