package src;

public class LimiteException {
	private long serialVersionUID;
	public LimiteException(String message) {
		
	}
}
