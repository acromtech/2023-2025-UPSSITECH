package src;

public class CasePlateau {
	//Attributes
	//Constructor
	public CasePlateau() {
		
	}
	
	//Methods
	public Navire[] getLesOcuupants(){
		
	}
	public void addUnOccupant(Navire nouvelOccupant) {
		
	}
	public String toString() {
		
	}
	public boolean estOccupee() {
		
	}
	public boolean estPleine() {
		
	}
	public String affichage() {
		
	}
	public void removeUnOccupant(Navire n){
		
	}
}
