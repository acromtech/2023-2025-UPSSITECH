package src;

public class Chalutier extends NavireSurface {
	public Chalutier(int rang, int numEq) {
	}
	public String toString() {
		
	}
}
