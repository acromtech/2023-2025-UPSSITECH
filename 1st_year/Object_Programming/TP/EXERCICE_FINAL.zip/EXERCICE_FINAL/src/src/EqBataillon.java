package src;

public class EqBataillon extends Equipe {
	public EqBataillon(int idEq,Nature n) {
		super(n);
		//myStatut=Statut...
	}
}
