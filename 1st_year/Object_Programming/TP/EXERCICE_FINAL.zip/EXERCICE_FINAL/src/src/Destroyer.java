package src;

public class Destroyer extends NavireSurface {
	public Destroyer(int rang,int numEq) {
		
	}
	public String toString() {
		
	}
}
