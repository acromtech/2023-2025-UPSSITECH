package src;

public enum Statut {
	MILITAIRE,
	NEUTRE
}
