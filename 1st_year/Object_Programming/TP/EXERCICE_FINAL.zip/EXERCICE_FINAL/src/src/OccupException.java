package src;

public class OccupException extends Exception {
	private long serialVersionUID;
	public OccupException(String mes) {
		super(mes);
	}
}