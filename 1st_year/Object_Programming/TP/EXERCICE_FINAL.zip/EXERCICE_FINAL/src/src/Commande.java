package src;

public class Commande extends Jeu{
	//Attributes
	private int idNavire;
	private Action actionChoisie;
	private Direction directionChoisie;
	
	//Constructors
	public Commande(Equipe eq,int id,int a, int d) {
		
	}
	public Commande(Equipe eq, String strIdNav, String strAction,String strDirection) {
		
	}
	
	//Methods
	public Equipe getEquipe() {
		
	}
	public int getIdNavire() {
		
	}
	public void setIdNavire(int idNavire) {
		
	}
	public Action getActionChoisie() {
		
	}
	public void setActionChoisie(Action actionChoisie) {
		
	}
	public Direction getDirectionChoisie() {
		
	}
	public void setDirectionChoisie(Direction directionChoisie) {
		
	}
	public String toString() {
		
	}
	
}
