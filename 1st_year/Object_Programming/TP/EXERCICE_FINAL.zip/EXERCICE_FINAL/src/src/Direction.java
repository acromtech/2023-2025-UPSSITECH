package src;

public enum Direction {
	NORD,
	SUD,
	EST,
	OUEST
}
