package src;

public class SousMarin extends NavireProfondeur {

}
