package src;

public class EqPecheur extends Equipe{
	public EqPecheur(int idEq, Nature n) {
		super(n);
	}
}
