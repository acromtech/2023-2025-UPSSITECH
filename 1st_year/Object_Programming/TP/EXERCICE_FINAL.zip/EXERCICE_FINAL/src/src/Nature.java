package src;

public enum Nature {
	HUMAIN,
	IA
}
