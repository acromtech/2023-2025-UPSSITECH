package src;

public abstract class Navire extends Jeu{
	protected int ident;
	protected TypeNav myType;
	protected String strAffichage;
	protected int numEq;
	protected int etat;
	protected int portee;
	protected int vitesse;
	
	public Navire(int rang,TypeNav t,int numEq) {
		
	}
	public int getIdent() {
		
	}
	public int getNumEq() {
		
	}
	public Point getPosition() {
		
	}
	public void setPosition(Point position) {
		
	}
	public TypeNav getType() {
		
	}
	public boolean estValide() {
		
	}
	public boolean estCoule() {
		
	}
	public void seDeplacer(Point pos) {
		
	}
	public int getPortee() {
		
	}
	public int getVitesse() {
		
	}
	public void setCoule() {
		
	}
	public String toString() {
		
	}
}
