package src;

public abstract class NavireSurface extends Navire {
	public NavireSurface(int rang,TypeNav t,int numEq) {
		super(rang,t,numEq);
	}
}
