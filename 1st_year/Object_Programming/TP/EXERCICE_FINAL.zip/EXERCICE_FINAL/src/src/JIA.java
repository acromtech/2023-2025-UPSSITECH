package src;

public abstract interface JIA extends Joueur {
	public void tirageAleatoire() {
		
	}
}
