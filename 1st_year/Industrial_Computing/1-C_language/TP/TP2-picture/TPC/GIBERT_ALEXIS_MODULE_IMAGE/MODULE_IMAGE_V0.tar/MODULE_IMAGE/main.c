#include <stdio.h>
#include <stdlib.h>

#include "ferrane_module_image.h"

/* AUTEUR : ISABELLE FERRANE                       */
/* DATE CREATION : 11/10/2018                      */
/*-------------------------------------------------*/

/* PROGRAMME DE TEST de FERRANE_MODULE_IMAGE */

int main(void)
{
	/* séquence de test des fonction de FERRANE_MODULE_IMAGE */
	printf("DEBUT DE TEST MODULE \n");

	test_prog();
	
	printf("DEBUT DE TEST MODULE \n");
	
	return EXIT_SUCCESS;   /*-- valeur de retour = succès exécution défini dans stdlib.h */
	
}
