#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "gibert_module_image.h"

int IMAGE[NB_MAX][NB_MAX];

/* AUTEUR : ALEXIS GIBERT                       */
/* DATE CREATION : 30/10/2022                      */
/*-------------------------------------------------*/

/* DEFINITIONS DES FONCTIONS déclarées dans le .h */

/*-------------------------------------------------------------------------------
Affiche la transformation de l’image suivant le niveau de gris donné en paramètre.
De plus, elle renverra une valeur entière qui vaudra suivant le cas :
	[-1]	si la valeur du niveau est supérieure à 256, 
	[0]	si le niveau n’est pas une puissance de 2,
	[1]	sinon (traitement effectué).
-------------------------------------------------------------------------------*/
int afficher_image_codee(int niveau){
  int nbl,nbc,pxlc=0,i,j;
  printf("\n\r[Passage vers une image a %d niveau de gris]\n\r",niveau);
  if(niveau<256){
    if((int)log2(niveau)==log2(niveau)){
      scanf("%d",&nbl);
      scanf("%d",&nbc);
      for(i=0;i<nbl;i++){
        for(j=0;j<nbc;j++){
          scanf("%d",&pxlc);
          printf("%5d",((pxlc*niveau)/256));
        }
        printf("\n\r");
      }
    }
    else return 0;
  }
  else return -1;
  return 1;
}

/*-------------------------------------------------------------------------------
Lit et mémorise la matrice à partir des valeurs lues sur l’entrée standard. 
Elle reçoit en paramètre les valeurs N et M correspondant respectivement au nombre de lignes et au nombre de colonnes de la matrice représentant l’image. 
Ces valeurs auront été lues et testées par le programme principal. 
De plus, cette fonction renverra :
	[0]	si la mémorisation ne peut pas être faite,
	[1]	sinon (traitement effectué).
-------------------------------------------------------------------------------*/
int lire_image(int N, int M){
  int i,j,val;
  printf("\n\r[Lecture de la matrice de %d lignes et %d colonnes] : ",N,M);
  if(N<=NB_MAX && N>0 && M<=NB_MAX && M>0){
    for(i=0;i<N;i++){
      for(j=0;j<M;j++){
        scanf("%d",&val);
	IMAGE[i][j]=val;
      }
    }
    return 1;
  }
  else return 0;
}


/*-------------------------------------------------------------------------------
Effectue la transformation de l’image suivant le niveau de gris, les valeurs de N (nombre de lignes de la matrice) et M (nombre de colonne de la matrice) en paramètre.
Elle veillera a enregistrer les nouvelles valeurs dans la matrice mémorisée.
De plus, elle renverra une valeur entière qui vaudra suivant le cas :
	[-1]	si la valeur du niveau est supérieure à 256, 
	[0]	si le niveau n’est pas une puissance de 2,
	[1]	sinon (traitement effectué).
-------------------------------------------------------------------------------*/
int afficher_image_codee_bis(int niveau, int N, int M){
  int i,j;
  printf("\n\r[Passage vers une image a %d niveau de gris]\n\r",niveau);
  if(niveau<256){
    if((int)log2(niveau)==log2(niveau)){
      for(i=0;i<N;i++){
        for(j=0;j<M;j++){
          IMAGE[i][j]=((IMAGE[i][j])*niveau)/256;
          printf("%5d",IMAGE[i][j]);
        }
        printf("\n\r");
      }
    }
    else return 0;
  }
  else return -1;
  return 1;
}
