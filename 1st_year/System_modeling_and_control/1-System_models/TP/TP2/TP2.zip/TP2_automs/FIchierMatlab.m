clear all;
close all;
clc;

%Constantes
Km=10;
Tm=0.3;
Kr=1/9;
Ks=10;
Kg=0.105;
K1=2.4;
K2=0.76;
K3=2;

%Blocs
sys1=tf(Km, [Tm 1]);
sys2=tf(1, [1 0]);

sysB11=feedback(sys1,K2*Kg);
sysB12=feedback(sysB11*Kr*sys2*Ks,K1);
sys=K3*sysB12;

figure(1);
clf;
S1=stepinfo(sys);
step(sys);
title('echelon unitaire');

figure(2);
clf;
S2=stepinfo(sys);
impulse(sys);
title('R�ponse a impultion');

figure(3);
clf;
S3=stepinfo(sys);
bode(sys);
title('R�ponse fr�quentielle');

disp(S1);
disp(S2);
disp(S3);