K_e = 10;
K_s = 10;
K_g = 0.105;
K_m = 5.619;
T_m = 0.336 ;
K_1 = 1;
K = K_1*K_m*K_s;
A = 9*T_m ;

% Fonction de transfert en boucle fermé
ssys1=tf([K_m],[T_m 1]);
ssys2=tf([1],[1 0]);
ssys3=tf([1],[9]);
ssys4=ssys1*ssys2*ssys3*K_1;
ssys5=feedback(ssys4,K_s);
sysBF=ssys5*K_e;

% Fonction de transfert en boucle ouverte
sysBO=ssys1*ssys2*ssys3*K_1*K_s;

% Détermination des caractéristiques fréquentielles du système non corrigé en boucle ouverte
figure(1);
[Gm,Pm,Wcg,Wcp]=margin(sysBO);

% Tracé du lieux des racines (Evans)
rltool(sysBF);

% Analyse des performances temporelles de l'asservissement (FTBF)
figure(2);
step(sysBF);
stepinfo(sysBF)

% Analyse des performances fréquentielles de l'asservissement (FTBF)
figure(3);
bode(sysBF);

% Identification des coefficiants du correcteur a avance de phase
marge_phase_desiree=45;
alpha = 1.5;
delta_phi = alpha*(marge_phase_desiree - Pm) % Avec Pm la marge de phase actuelle
a = (1+sind(delta_phi))/(1-sind(delta_phi))
tau = 1/(Wcp*sqrt(a))
D1 = tf([a*tau 1],[tau 1]);

% Met a jour les fonctions de transfert du système considéré
ssys6=ssys1*ssys2*ssys3*K_1*D1;
ssys7=feedback(ssys6,K_s);
sysBF_AP=ssys7*K_e
sysBO_AP=ssys1*ssys2*ssys3*K_1*D1*K_s

% Vérification de la marge de phase imposée (45°)
figure(4);
margin(sysBO_AP);

% Analyse des performances temporelles de l'asservissement (FTBF)
figure(5);
step(sysBF_AP);
stepinfo(sysBF_AP)
title('Reponse temporelle echelonee du signal corrige (avance de phase)')

% Analyse des performances fréquentielles de l'asservissement (FTBF)
figure(6);
bode(sysBF_AP);

%p = tf('p');
%N = (K_1*K_m*K_s) / (9*T_m*p^2 + 9*p);
%rltool(N);