% Modélisation du robot SCARA Mitsubishi

%% PARTIE NON MODIFIABLE 
%% INITIALISATION 
%% NE PAS MODIFIER CETTE PARTIE!!!!!!

clc
clear all
close all

% Géométrie du robot
h = 0.8;
L1 = 0.4;
L2 = 0.4;
L3 = 0.2;

% Mesures renvoyées par la caméra (position de la pièce à saisir dans Rc):
xP = 0.5; yP = 0.2; 

% Différentes configurations de test pour les MGD/MGI
Q1 = zeros(1,4);
Q2 = [pi/2 0 0 0];
Q3 = [0 pi/2 0 0];
Q4 = [0 0 -0.5 pi/2];
Q5 = [pi/2 pi/2 -0.5 0];

% Paramètres des actionneurs
r = 1/200; % rapport de réduction
Km = 0.3; % constante de couple
R = 1; % resistance induit
B = 1/80; % coefficient de frottement
Jeff1 = 0.02; % Inertie efficace articulation 1
Jeff2 = 0.01; % Inertie efficace articulation 2

% Gains de commande
k1=0.01;
k2=0.02;

% FIN DE LA PARTIE NON MODIFIABLE

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Choix de la config de test parmi celles définies au-dessus (ou d'autres à votre discrétion)
q = Q1;

%% A COMPLETER

%%% SECTION 2.1
	% Utilisation de la fonction drawBM
    drawBM(q, 0, 0)

	% Calcul du MGD et afficher le repère outil
    [T01,T02,T03,T04]=MGD(h,L1,L2,q);
    
%%% SECTION 2.2

	% Calculer ici TOC la matrice de passage homogène entre R0 et Rc
    T2C=[-1 0 0 L2+L3;
        0 1 0 0;
        0 0 -1 0;
        0 0 0 1];

	% Détermination de la situation de la pièce dans R0
    T0C=T02*T2C;
    hold on
    drawFrame(T0C,"R0C",0.2);
    hold off
    
	% Données: position de la pièce dans Rc : (xP, yP, h), orientation : cf. énoncé
    
  	% Afficher la position (X,Y,Z) de la pièce dans R0 --> Fonction : plot3(X,Y,Z,'ro');
    hold on
	X=L1+L2+L3-xP;
    Z=0;
    Y=yP;
    plot3(X,Y,Z,'ro');
    hold off
    
    % Déduire la situation de la pièce dans R0
    % situation = position + orientation
    % -> LA MATRICE DE PASSAGE
    TCD=[1 0 0 xP;
        0 1 0 yP;
        0 0 1 h;
        0 0 0 1];
    T0D=T0C*TCD;
    
  	% Calcul du MGI et vérification
    Qtot=mgi_mitsu(T0D)
    
  	% Affichage
    hold on
    drawFrame(T0D,"R0D",0.2);
    hold off

%%% SECTION 2.3

	% Détermination des représentations d'état des actionneurs


	% Réponse indicielle des actionneurs seuls


	% Modification des représentations d'état pour prendre en compte que seules les positions qi sont mesurées

	
	% Réponse indicielle des asservissements


	% Calcul de la réponse indicielle de chaque actionneur et dessin de la trajectoire

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 



function [T01,T02,T03,T04]= MGD(h,L1,L2,q)
    T01=[cos(q(1)) -sin(q(1)) 0 0;
         sin(q(1)) cos(q(1)) 0 0;
         0 0 1 h;
         0 0 0 1];

    T12=[cos(q(2)) -sin(q(2)) 0 L1;
         sin(q(2)) cos(q(2)) 0 0;
         0 0 1 0;
         0 0 0 1];

    T23=[1 0 0 L2;
         0 1 0 0;
         0 0 1 q(3);
         0 0 0 1];

    T34=[cos(q(4)) -sin(q(4)) 0 0;
        sin(q(4)) cos(q(4)) 0 0;
        0 0 1 0;
        0 0 0 1];

    T02=T01*T12;
    T03=T02*T23;
    T04=T03*T34;

    % Ne pas oublier hold on si nécessaire pour la superposition des courbes
    hold on
    drawFrame(T01,"R01",0.2);
    drawFrame(T02,"R02",0.2);
    drawFrame(T03,"R03",0.2);
    drawFrame(T04,"R04",0.2);
    hold off
end


